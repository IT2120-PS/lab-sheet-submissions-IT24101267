getwd()
setwd("C:\\Users\\it24101267\\Desktop\\PS LAB 4")
getwd()
branch_data<-read.csv("Exercise.txt",header = TRUE,sep=",")
head(branch_data)

check_variable <- function(x)
  if(is.numeric(x)){
    return ("Numeric (Ratioscale"))
  }else if(is.factor(x)||is.character(x)){
    return("")
  }
str (branch_data)
boxplot(branch_data$Sales,
        main="Box plot for Sales",
        ylab="Sales Amount",
        outline=TRUE,
        horizontal=FALSE)

# Five-number summary for advertising
summary(branch_data$advertising)

# Calculate IQR explicitly
iqr_advertising <- IQR(branch_data$advertising)
cat("IQR of advertising:", iqr_advertising, "\n")

# Function to find outliers using the IQR method
find_outliers <- function(x) {
  q1 <- quantile(x, 0.25)
  q3 <- quantile(x, 0.75)
  iqr <- q3 - q1
  lower_bound <- q1 - 1.5 * iqr
  upper_bound <- q3 + 1.5 * iqr
  outliers <- x[x < lower_bound | x > upper_bound]
  return(outliers)
}

# Check for outliers in years
years_outliers <- find_outliers(branch_data$years)
if (length(years_outliers) == 0) {
  cat("No outliers in years variable.\n")
} else {
  cat("Outliers in years:", years_outliers, "\n")
}
